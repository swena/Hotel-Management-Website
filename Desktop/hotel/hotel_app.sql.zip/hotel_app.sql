-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 30, 2012 at 10:27 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Admin_loginid` text NOT NULL,
  `Admin_login_email` varchar(100) NOT NULL,
  `Admin_login_password` varchar(100) NOT NULL,
  `Hotel_name` text NOT NULL,
  `Hotel_description` text NOT NULL,
  `Hotel_logo` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`ID`, `Admin_loginid`, `Admin_login_email`, `Admin_login_password`, `Hotel_name`, `Hotel_description`, `Hotel_logo`) VALUES
(1, 'tajgroup', 'tajgroup@gmail.com', 'a46f8df0780e145d2d31e9454e1c7ed9', 'The Taj Group', 'One of the Finest Hotel in the World', 'taj_group.gif'),
(4, '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', ''),
(3, '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', ''),
(5, '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_customer`
--

CREATE TABLE IF NOT EXISTS `hotel_customer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `UserName` text NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Birthday` date NOT NULL,
  `Gender` text NOT NULL,
  `MobileNo` int(15) NOT NULL,
  `LandlineNo` int(10) NOT NULL,
  `Religion` text NOT NULL,
  `Nationality` text NOT NULL,
  `PostalID` int(10) NOT NULL,
  `Date` date NOT NULL,
  `City` text NOT NULL,
  `State` text NOT NULL,
  `Country` text NOT NULL,
  `Taddress` text NOT NULL,
  `Paddress` text NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Status` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `hotel_customer`
--

INSERT INTO `hotel_customer` (`ID`, `FirstName`, `LastName`, `UserName`, `Password`, `Birthday`, `Gender`, `MobileNo`, `LandlineNo`, `Religion`, `Nationality`, `PostalID`, `Date`, `City`, `State`, `Country`, `Taddress`, `Paddress`, `Email`, `Status`) VALUES
(11, 'shefali', 'gupta', 'swena', '2d488a349a85cb8e9c6c0a0888fd4e06', '1992-01-03', 'F', 0, 2147483647, 'gupta.swena@gmail.com', '5644224158', 0, '0000-00-00', '2012-06-28', 'Bharatpur', 'rajasthan', 'india', '162, Krishna Nagar', '162, Krishna Nagar', 0),
(12, 'FirstName1', 'LastName1', 'swena', '2d488a349a85cb8e9c6c0a0888fd4e06', '2012-06-13', 'F', 0, 2147483647, 'swenagupta@sify.com', '5644224158', 0, '0000-00-00', '2012-06-19', 'Bharatpur', 'Rajasthan', 'India', '162, Krishna Nagar', '162, Krishna Nagar', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hotel_staff`
--

CREATE TABLE IF NOT EXISTS `hotel_staff` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `UserName` varchar(30) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Birthday` date NOT NULL,
  `Gender` text NOT NULL,
  `Qualification` varchar(30) NOT NULL,
  `MobileNo` int(15) NOT NULL,
  `Email` text NOT NULL,
  `LandlineNo` int(12) NOT NULL,
  `Religion` text NOT NULL,
  `Nationality` text NOT NULL,
  `PostalID` int(10) NOT NULL,
  `Date` date NOT NULL,
  `City` text NOT NULL,
  `State` text NOT NULL,
  `Country` text NOT NULL,
  `Taddress` longtext NOT NULL,
  `Paddress` longtext NOT NULL,
  `Status` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `hotel_staff`
--

INSERT INTO `hotel_staff` (`ID`, `FirstName`, `LastName`, `UserName`, `Password`, `Birthday`, `Gender`, `Qualification`, `MobileNo`, `Email`, `LandlineNo`, `Religion`, `Nationality`, `PostalID`, `Date`, `City`, `State`, `Country`, `Taddress`, `Paddress`, `Status`) VALUES
(25, 'shefali', 'gupta', 'swena', '2d488a349a85cb8e9c6c0a0888fd4e06', '2012-06-04', 'F', 'b.tech', 987, 'swenagupta@sify.com', 2147483647, 'Hindu', 'indian', 321001, '2012-06-06', 'Bharatpur', 'raj', 'india', 'kkk', 'kkk', 1),
(26, 'swena', 'gupta', 'swena', 'swena', '2012-06-08', 'F', 'b.tech', 2147483647, 'swenagupta@sify.com', 2147483647, 'Hindu', 'Indian', 321001, '2012-06-29', 'bharatpur', 'rajasthan', 'india', 'krishna nagar', 'krishna nagar', 0),
(28, 'alka', 'gupta', 'alka', 'alka', '2012-06-13', 'F', 'b.tech', 2147483647, 'alka.sanjeev24@gmail.com', 2147483647, 'Hindu', 'Indian', 321001, '2012-06-29', 'bharatpur', 'rajasthan', 'India', '162, Krishna Nagar', '162, Krishna Nagar', 1),
(29, 'alka', 'gupta', 'alka', 'alka', '2012-06-13', 'F', 'b.tech', 2147483647, 'alka.sanjeev24@gmail.com', 2147483647, 'Hindu', 'Indian', 321001, '2012-06-29', 'bharatpur', 'rajasthan', 'India', '162, Krishna Nagar', '162, Krishna Nagar', 0);
