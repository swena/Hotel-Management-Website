-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 27, 2012 at 01:01 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Admin _loginid` text NOT NULL,
  `Admin_login_email` varchar(50) NOT NULL,
  `Admin_login_password` varchar(30) NOT NULL,
  `Hotel_name` text NOT NULL,
  `Hotel_description` text NOT NULL,
  `Hotel_logo` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `admin_login`
--


-- --------------------------------------------------------

--
-- Table structure for table `cancellation_form`
--

CREATE TABLE IF NOT EXISTS `cancellation_form` (
  `cancellation_cid` int(10) NOT NULL AUTO_INCREMENT,
  `cancellation_cname` text NOT NULL,
  `cancellation_cbookroom` int(100) NOT NULL,
  `cancellation_carrival` date NOT NULL,
  `cancellation_cdeparture` date NOT NULL,
  `cancellation_cbookcofirmroom` int(100) NOT NULL,
  `cancellation_cremarks` text NOT NULL,
  `cancellation_crequestedby` text NOT NULL,
  `cancellation_creceivedby` text NOT NULL,
  `cancellation_cdate` date NOT NULL,
  PRIMARY KEY (`cancellation_cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cancellation_form`
--


-- --------------------------------------------------------

--
-- Table structure for table `guestregistration_form`
--

CREATE TABLE IF NOT EXISTS `guestregistration_form` (
  `guest_id` int(10) NOT NULL AUTO_INCREMENT,
  `guest_name` text NOT NULL,
  `guest_organisation` varchar(100) NOT NULL,
  `guest_designation` text NOT NULL,
  `guest_nationality` text NOT NULL,
  `guest_arrivaldate` date NOT NULL,
  `guest_time` time NOT NULL,
  `guest_departuredate` date NOT NULL,
  `guest_visitpurpose` text NOT NULL,
  `guest_arrivedfrom` text NOT NULL,
  `guest_probabledestination` text NOT NULL,
  `guest_checkoutbill` int(50) NOT NULL,
  `guest_creditcardno` int(100) NOT NULL,
  `guest_bookedby` text NOT NULL,
  `guest_passportno` int(150) NOT NULL,
  `guest_issuedate` date NOT NULL,
  `guest_issueplace` text NOT NULL,
  `guest_dob` date NOT NULL,
  `guest_arrivaldateinindia` date NOT NULL,
  `guest_certificate` text NOT NULL,
  `guest_date` date NOT NULL,
  `guest_place` text NOT NULL,
  `guest_noofpersons` int(100) NOT NULL,
  `guest_roomno` int(100) NOT NULL,
  `guest_rate` int(11) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `guestregistration_form`
--


-- --------------------------------------------------------

--
-- Table structure for table `hotel_customer`
--

CREATE TABLE IF NOT EXISTS `hotel_customer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `UserName` text NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Birthday` date NOT NULL,
  `Gender` text NOT NULL,
  `MobileNo` int(15) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Status` binary(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hotel_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `hotel_staff`
--

CREATE TABLE IF NOT EXISTS `hotel_staff` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `UserName` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Birthday` date NOT NULL,
  `Gender` text NOT NULL,
  `Qualification` varchar(30) NOT NULL,
  `MobileNo` int(15) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Status` binary(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hotel_staff`
--


-- --------------------------------------------------------

--
-- Table structure for table `query_form`
--

CREATE TABLE IF NOT EXISTS `query_form` (
  `query_cid` int(11) NOT NULL,
  `query_cname` text NOT NULL,
  `query_cemail` varchar(100) NOT NULL,
  `query_cmessage` text NOT NULL,
  `query_cphone` int(15) NOT NULL,
  `query_ccompanyname` text NOT NULL,
  `query_cmobile` int(15) NOT NULL,
  `query_ccountry` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `query_form`
--


-- --------------------------------------------------------

--
-- Table structure for table `reservation_chart`
--

CREATE TABLE IF NOT EXISTS `reservation_chart` (
  `reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_roomtype` text NOT NULL,
  `reservation_roomno` int(100) NOT NULL,
  `reservation_checkindate` date NOT NULL,
  `reservation_checkoutdate` date NOT NULL,
  PRIMARY KEY (`reservation_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `reservation_chart`
--


-- --------------------------------------------------------

--
-- Table structure for table `reservation_form`
--

CREATE TABLE IF NOT EXISTS `reservation_form` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_surname` text NOT NULL,
  `customer_firstname` text NOT NULL,
  `customer_willarrivaday` text NOT NULL,
  `customer_arrrival_date` date NOT NULL,
  `customer_hour` time NOT NULL,
  `customer_flight` text NOT NULL,
  `customer_departure` date NOT NULL,
  `customer_date` date NOT NULL,
  `customer_time` time NOT NULL,
  `customer_accomandation` text NOT NULL,
  `customer_creditno` int(20) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `reservation_form`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
